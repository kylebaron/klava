.logit <- function(x) {
  log(x/(1-x))
}
.alogit <- function(x) exp(x)/(1+exp(x))
ident <- function(x) x

is_fixed <- function(x) {
  sapply(x, function(w) w[["fixed"]])
}

pars <- function(x) x[["p"]]
fixed <- function(x) x[["fx"]]

##' Create a new pars object.
##'
##' @param ... lists with parameter information
##' @export
new_pars <- function(...) {
  x <- new("parset", data=list(...))
  names(x@data) <- names(x)
  return(x)
}

##' Get parameter names.
##'
##' @param x pars object
##' @export
labels.pars <- function(x,...) {
  unlist(lapply(x, function(y) y$name))
}
##' Get parameter values.
##'
##' @param x pars object
##' @export
##'
values <- function(x,...) {
  a <- unlist(lapply(x, function(y) y$value))
  names(a) <- labels(x)
  a
}

##' Create a list of log-transformed parameters.
##'
##' @param name the parameter name
##' @param value the parameter value
##' @export
##'
log_par <- function(name,value,...) {
  new("logpar", name=name, value=value,fixed=FALSE)
}
##' Create a list of logit-transformed parameters.
##'
##' @param name the parameter name
##' @param value the parameter value
##' @export
##'
logit_par <- function(name,value,fixed=FALSE,...) {
  new("logitpar",name=name,value=value,fixed=FALSE)
}
##' Create a list of untransformed parameters.
##'
##' @param name the parameter name
##' @param value the parameter value
##' @export
##'
ident_par <- function(name,value,...) {
  new("par", name=name, value=value,fixed=FALSE)
}
##' Create a list of fixed parameters.
##'
##' @param name the parameter name
##' @param value the parameter value
##' @export
##'
fixed_par <- function(name,value,...) {
  make_par(name,value,fixed=TRUE,...)
}

make_par <- function(name,value,to=ident,from=ident,fixed=FALSE,...) {
  list(name=name,value=value,to=to,from=from,fixed=fixed)
}




##' Print the parameter list.
##' @param x pars object
##'
##' @export
##'
print.pars <- function(x) {
  print(data.frame(name=labels(x), value=values(x)))
}


